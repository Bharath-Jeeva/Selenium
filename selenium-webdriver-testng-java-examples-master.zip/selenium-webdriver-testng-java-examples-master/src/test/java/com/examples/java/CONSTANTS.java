package com.examples.java;

/**
 * Created by janesh on 7/22/2015.
 */
public class CONSTANTS {

    public static final String  BASE_URL="http://google.com";
    public  final String BASE_URL2= "http://www.pragmatictestlabs.com";


    public static String  testMethod1(){
       // System.out.println();
        return " I am static method ";
    }

    public String testMethod2(){
        return "Method 2";
    }
}
