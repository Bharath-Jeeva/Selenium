package com.examples.email;

/**
 * Created by janesh on 7/15/2015.
 */
public class EmailWithHTMLBody {
}
