package com.util;

/**
 * Created by janesh on 7/12/2015.
 */
public class CONSTANTS {

    public  static final String BASE_URL = "http://professional.demo.orangehrmlive.com/symfony/web/index.php/auth/login";


}
