These examples are created for the delegates who attended the training at Pragmatic Test Labs
